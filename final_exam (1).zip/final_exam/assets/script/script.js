// Globale Header
// jQuery(document).ready(($) => {
window.addEventListener("load", () => {
    document.getElementById("header").innerHTML = `<header class="site-header">
    <div class="header">
    <div class="logo">
        <!-- Insert your logo image here -->
        <image src="./assets/images/sample-logo.png">
    </div>
    <div class="menu">
        <a href="#">Home</a>
        <span>|</span>
        <a href="#">About</a>
        <span>|</span>
        <a href="#">Contact</a>
    </div>
    <input class="search-input" type="text" placeholder="Search...">
</div>
    </header>`;

    // Globale Footer
    document.getElementById("footer").innerHTML = `<footer class="main_footer">
    <div class="grid-container__footer">
    <div class="footer_column__logo">
    <!-- Content for the second column -->
    <img class="image" src="./assets/images/sample-logo.png" alt="Image">
    </div>
    <div class="footer_column__text">
        <section class="info__section">
            <div class="container">
            <h2 class="info__section-title">Title</h2>
                <p class="info__section-dec">lorem ipsum dolor sit amet,consectetur adipiscing elit,sed do elusmod tempor incididunt ut labore et dolore magna aliqua.Ut enim ad minim veniam</p>
            </div>
        </section>
    </div>
</div>
</footer>`;
});

// });

// NavBar
setTimeout(() => {
    const menuToggle = document.getElementById("menu-toggle");
    const mainNavigation = document.querySelector(".main-navigation");
    const menuItems = document.querySelectorAll(".menu-item__link");

    menuToggle.addEventListener("click", () => {
        mainNavigation.classList.toggle("show-menu");
    });

    // Highlight the active menu item
    menuItems.forEach((item) => {
        if (item.href === window.location.href) {
            item.classList.add("active");
        }
    });
    window.onscroll = function () {
        myFunction();
    };
    var header = document.getElementById("header");
    var sticky = header.offsetTop;

    var myFunction = () => {
        if (window.pageYOffset > sticky) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    };
}, 2000);